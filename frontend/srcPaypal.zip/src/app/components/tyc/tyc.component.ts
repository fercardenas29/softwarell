import { Component } from '@angular/core';

@Component({
  selector: 'app-tyc',
  templateUrl: './tyc.component.html',
  styleUrls: ['./tyc.component.css']
})
export class TycComponent {

}
