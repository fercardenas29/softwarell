export var Global = {
    url:'http://localhost:3700/hotel/'
}